import logo from './logo.svg';
import './App.css';
import MonsoonRecipeHub from './components/MonsoonRecipeHub';

function App() {
  return (
    <div className="App">
      <MonsoonRecipeHub/>
    </div>
  );
}

export default App;
