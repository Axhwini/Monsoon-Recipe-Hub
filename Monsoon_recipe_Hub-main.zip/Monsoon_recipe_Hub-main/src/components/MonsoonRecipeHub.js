import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardMedia, Typography, TextField, Button, AppBar, Toolbar, Grid, Container, Chip, IconButton, Dialog, DialogTitle, DialogContent, DialogActions, Box, Tabs, Tab, Paper, InputAdornment, Avatar } from '@mui/material';
import { Favorite, FavoriteBorder, Comment, Person, Search, Add, RestaurantMenu, LocalDining, Cake, LocalCafe, Whatshot } from '@mui/icons-material';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import chaiimag from './Images/chai.jpg';
import gulab_jamum from './Images/gulab jamun.png';
import mango_lassi from './Images/mango lassi.png';
import pakoras from './Images/pakoras.jpg';
import paneer_butter from './Images/paneer butter masala.png';
import samosas from './Images/samosas.jpg';

// Create a custom theme with warm, cozy colors
const theme = createTheme({
  palette: {
    primary: {
      main: '#8B4513', // Warm brown
    },
    secondary: {
      main: '#D2691E', // Chocolate
    },
    background: {
      default: '#FFF8E1', // Warm light beige
      paper: '#FFFAF0', // Lighter warm background
    },
  },
  typography: {
    fontFamily: '"Playfair Display", "Georgia", serif',
  },
});

// Mock data for recipes
const mockRecipes = [
  {
    id: 1,
    title: 'Spicy Masala Chai',
    description: 'A traditional Indian spiced tea with a kick of heat',
    ingredients: 'Tea leaves, milk, water, ginger, cardamom, cloves, cinnamon, black pepper, sugar',
    instructions: '1. Boil water with spices\n2. Add tea leaves\n3. Add milk and simmer\n4. Strain and serve hot',
    image: chaiimag,
    tags: ['spicy', 'chai', 'hot'],
    type: 'beverage',
    likes: 23,
    comments: [
      { user: 'TeaLover', content: 'Perfect for rainy days!' },
      { user: 'SpiceFan', content: 'Added extra pepper, amazing!' }
    ],
    author: 'ChaiMaster',
    created: '2024-01-15'
  },
  {
    id: 2,
    title: 'Crispy Samosas',
    description: 'Delicious potato-filled pastry triangles',
    ingredients: 'Potatoes, peas, flour, spices, oil',
    instructions: '1. Prepare dough\n2. Make potato filling\n3. Fill and shape samosas\n4. Deep fry until golden',
    image: samosas,
    tags: ['spicy', 'snacks', 'fried'],
    type: 'snack',
    likes: 45,
    comments: [
      { user: 'Foodie123', content: 'Best samosa recipe ever!' }
    ],
    author: 'SnackQueen',
    created: '2024-01-10'
  },
  {
    id:3,
    title: 'Hot Pakoras',
    description: 'Crispy onion and potato fritters perfect for monsoons',
    ingredients: 'Onion, potato, chickpea flour, spices, oil',
    instructions: '1. Mix veggies with batter\n2. Deep fry until crispy\n3. Serve with chutney',
    image: pakoras,
    tags: ['snacks', 'spicy', 'fried'],
    type: 'snack',
    likes: 60,
    comments: [{ user: 'RainyDayFan', content: 'Best with chai!' }],
    author: 'StreetFoodie',
    created: '2024-01-18'
  },
  {
    id: 4,
    title: 'Mango Lassi',
    description: 'Refreshing yogurt-based mango drink',
    ingredients: 'Mango, yogurt, sugar, cardamom, ice',
    instructions: '1. Blend mango with yogurt\n2. Add sugar and cardamom\n3. Serve chilled with ice',
    image: mango_lassi,
    tags: ['sweet', 'beverage', 'refreshing'],
    type: 'beverage',
    likes: 31,
    comments: [],
    author: 'MangoLover',
    created: '2024-01-08'
  },
  {
    id: 5,
    title: 'Gulab Jamun',
    description: 'Soft fried dough balls soaked in sugar syrup',
    ingredients: 'Milk powder, sugar, cardamom, oil, flour',
    instructions: '1. Prepare dough\n2. Shape balls\n3. Fry & soak in sugar syrup',
    image: gulab_jamum,
    tags: ['sweet', 'dessert'],
    type: 'dessert',
    likes: 72,
    comments: [{ user: 'SweetTooth', content: 'Mouthwatering!' }],
    author: 'DessertKing',
    created: '2024-01-20'
  },
  {
    id: 6,
    title: 'Paneer Butter Masala',
    description: 'Rich and creamy paneer curry with buttery tomato sauce',
    ingredients: 'Paneer, butter, tomato, cream, spices',
    instructions: '1. Prepare tomato gravy\n2. Add paneer\n3. Simmer with butter and cream',
    image: paneer_butter,
    tags: ['main', 'curry', 'creamy'],
    type: 'main',
    likes: 90,
    comments: [{ user: 'VeggieLover', content: 'Best with naan!' }],
    author: 'ChefIndia',
    created: '2024-01-25'
  }
];

// Mock users for authentication
const mockUsers = [
  { username: 'user1', password: 'pass1', name: 'Cooking Fan' },
  { username: 'user2', password: 'pass2', name: 'Recipe Master' }
];

const MonsoonRecipeHub = () => {
  const [recipes, setRecipes] = useState(mockRecipes);
  const [filteredRecipes, setFilteredRecipes] = useState(mockRecipes);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState('all');
  const [selectedTag, setSelectedTag] = useState('all');
  const [user, setUser] = useState(null);
  const [loginOpen, setLoginOpen] = useState(false);
  const [registerOpen, setRegisterOpen] = useState(false);
  const [recipeOpen, setRecipeOpen] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });
  const [registerData, setRegisterData] = useState({ username: '', password: '', name: '' });
  const [newRecipe, setNewRecipe] = useState({
    title: '',
    description: '',
    ingredients: '',
    instructions: '',
    tags: '',
    type: '',
    image: ''
  });
  const [activeTab, setActiveTab] = useState(0);
  const [commentText, setCommentText] = useState('');

  // Filter recipes based on search, type, and tags
  useEffect(() => {
    let filtered = recipes;
    
    if (searchTerm) {
      filtered = filtered.filter(recipe => 
        recipe.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.ingredients.toLowerCase().includes(searchTerm.toLowerCase()) ||
        recipe.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
      );
    }
    
    if (selectedType !== 'all') {
      filtered = filtered.filter(recipe => recipe.type === selectedType);
    }
    
    if (selectedTag !== 'all') {
      filtered = filtered.filter(recipe => recipe.tags.includes(selectedTag));
    }
    
    setFilteredRecipes(filtered);
  }, [recipes, searchTerm, selectedType, selectedTag]);

  const handleLogin = () => {
    const foundUser = mockUsers.find(u => 
      u.username === loginData.username && u.password === loginData.password
    );
    
    if (foundUser) {
      setUser(foundUser);
      setLoginOpen(false);
      setLoginData({ username: '', password: '' });
    } else {
      alert('Invalid credentials');
    }
  };

  const handleRegister = () => {
    if (mockUsers.some(u => u.username === registerData.username)) {
      alert('Username already exists');
      return;
    }
    
    mockUsers.push({
      username: registerData.username,
      password: registerData.password,
      name: registerData.name
    });
    
    setUser({ username: registerData.username, name: registerData.name });
    setRegisterOpen(false);
    setRegisterData({ username: '', password: '', name: '' });
  };

  const handleLogout = () => {
    setUser(null);
  };

  const handleLike = (recipeId) => {
    setRecipes(recipes.map(recipe => 
      recipe.id === recipeId ? { ...recipe, likes: recipe.likes + 1 } : recipe
    ));
  };

  const handleAddComment = (recipeId) => {
    if (!commentText.trim()) return;
    
    setRecipes(recipes.map(recipe => 
      recipe.id === recipeId ? {
        ...recipe,
        comments: [...recipe.comments, { user: user?.name || 'Anonymous', content: commentText }]
      } : recipe
    ));
    
    setCommentText('');
  };

  const handleAddRecipe = () => {
    const tagsArray = newRecipe.tags.split(',').map(tag => tag.trim()).filter(tag => tag);
    
    const newRecipeObj = {
      id: recipes.length + 1,
      title: newRecipe.title,
      description: newRecipe.description,
      ingredients: newRecipe.ingredients,
      instructions: newRecipe.instructions,
      image: newRecipe.image || 'https://placeholder-image-service.onrender.com/image/400x300?prompt=delicious%20home%20cooked%20meal%20on%20a%20plate&id=recipe' + (recipes.length + 1),
      tags: tagsArray,
      type: newRecipe.type,
      likes: 0,
      comments: [],
      author: user?.name || 'Anonymous',
      created: new Date().toISOString().split('T')[0]
    };
    
    setRecipes([...recipes, newRecipeObj]);
    setRecipeOpen(false);
    setNewRecipe({
      title: '',
      description: '',
      ingredients: '',
      instructions: '',
      tags: '',
      type: '',
      image: ''
    });
  };

  const recipeTypes = ['all', 'beverage', 'snack', 'main', 'dessert'];
  const popularTags = ['all', 'spicy', 'sweet', 'chai', 'snacks', 'refreshing'];

  return (
    <ThemeProvider theme={theme}>
      <div style={{ minHeight: '100vh', backgroundColor: theme.palette.background.default }}>
        <AppBar position="static" sx={{ backgroundColor: theme.palette.primary.main }}>
          <Toolbar>
            <RestaurantMenu sx={{ mr: 2 }} />
            <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
              Monsoon Recipe Hub
            </Typography>
            
            <TextField
              size="small"
              placeholder="Search recipes..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <Search />
                  </InputAdornment>
                ),
              }}
              sx={{ 
                backgroundColor: 'rgba(255, 255, 255, 0.15)', 
                borderRadius: 1,
                mr: 2,
                '& .MuiInputBase-input': {
                  color: 'white'
                }
              }}
            />
            
            {user ? (
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <Avatar sx={{ width: 32, height: 32, mr: 1 }}>
                  <Person />
                </Avatar>
                <Typography sx={{ mr: 2 }}>{user.name}</Typography>
                <Button color="inherit" onClick={handleLogout}>Logout</Button>
              </Box>
            ) : (
              <Box>
                <Button color="inherit" onClick={() => setLoginOpen(true)}>Login</Button>
                <Button color="inherit" onClick={() => setRegisterOpen(true)}>Register</Button>
              </Box>
            )}
          </Toolbar>
        </AppBar>

        <Container maxWidth="lg" sx={{ py: 4 }}>
          <Paper sx={{ mb: 4, p: 2 }}>
            <Tabs value={activeTab} onChange={(e, newValue) => setActiveTab(newValue)}>
              <Tab icon={<LocalDining />} label="All Recipes" />
              <Tab icon={<Cake />} label="Desserts" onClick={() => setSelectedType('dessert')} />
              <Tab icon={<LocalCafe />} label="Beverages" onClick={() => setSelectedType('beverage')} />
              <Tab icon={<Whatshot />} label="Spicy" onClick={() => setSelectedTag('spicy')} />
            </Tabs>
            
            <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mt: 2 }}>
              {popularTags.map(tag => (
                <Chip
                  key={tag}
                  label={tag}
                  clickable
                  color={selectedTag === tag ? 'primary' : 'default'}
                  onClick={() => setSelectedTag(tag)}
                />
              ))}
            </Box>
          </Paper>

          {user && (
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mb: 3 }}>
              <Button
                variant="contained"
                startIcon={<Add />}
                onClick={() => setRecipeOpen(true)}
                sx={{ backgroundColor: theme.palette.secondary.main }}
              >
                Add Recipe
              </Button>
            </Box>
          )}

          <Grid container spacing={4}>
            {filteredRecipes.map((recipe) => (
              <Grid item xs={12} sm={6} md={4} key={recipe.id}>
                <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                  <CardMedia
                    component="img"
                    height="200"
                    image={recipe.image}
                    alt={recipe.title}
                  />
                  <CardContent sx={{ flexGrow: 1 }}>
                    <Typography gutterBottom variant="h5" component="h2">
                      {recipe.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
                      {recipe.description}
                    </Typography>
                    
                    <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5, mb: 2 }}>
                      {recipe.tags.map((tag) => (
                        <Chip key={tag} label={tag} size="small" />
                      ))}
                    </Box>
                    
                    <Typography variant="caption" display="block" sx={{ mb: 2 }}>
                      By {recipe.author} • {recipe.created} • {recipe.type}
                    </Typography>
                    
                    <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <IconButton onClick={() => handleLike(recipe.id)} size="small">
                          {recipe.likes > 0 ? <Favorite color="error" /> : <FavoriteBorder />}
                        </IconButton>
                        <Typography variant="body2">{recipe.likes}</Typography>
                        
                        <IconButton size="small" sx={{ ml: 1 }}>
                          <Comment />
                        </IconButton>
                        <Typography variant="body2">{recipe.comments.length}</Typography>
                      </Box>
                    </Box>
                  </CardContent>
                </Card>
              </Grid>
            ))}
          </Grid>

          {filteredRecipes.length === 0 && (
            <Typography variant="h6" align="center" sx={{ mt: 4 }}>
              No recipes found. Try different search criteria.
            </Typography>
          )}
        </Container>

        {/* Login Dialog */}
        <Dialog open={loginOpen} onClose={() => setLoginOpen(false)}>
          <DialogTitle>Login</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Username"
              fullWidth
              variant="outlined"
              value={loginData.username}
              onChange={(e) => setLoginData({...loginData, username: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Password"
              type="password"
              fullWidth
              variant="outlined"
              value={loginData.password}
              onChange={(e) => setLoginData({...loginData, password: e.target.value})}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setLoginOpen(false)}>Cancel</Button>
            <Button onClick={handleLogin}>Login</Button>
          </DialogActions>
        </Dialog>

        {/* Register Dialog */}
        <Dialog open={registerOpen} onClose={() => setRegisterOpen(false)}>
          <DialogTitle>Register</DialogTitle>
          <DialogContent>
            <TextField
              autoFocus
              margin="dense"
              label="Username"
              fullWidth
              variant="outlined"
              value={registerData.username}
              onChange={(e) => setRegisterData({...registerData, username: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Password"
              type="password"
              fullWidth
              variant="outlined"
              value={registerData.password}
              onChange={(e) => setRegisterData({...registerData, password: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Display Name"
              fullWidth
              variant="outlined"
              value={registerData.name}
              onChange={(e) => setRegisterData({...registerData, name: e.target.value})}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setRegisterOpen(false)}>Cancel</Button>
            <Button onClick={handleRegister}>Register</Button>
          </DialogActions>
        </Dialog>

        {/* Add Recipe Dialog */}
        <Dialog open={recipeOpen} onClose={() => setRecipeOpen(false)} maxWidth="md" fullWidth>
          <DialogTitle>Add New Recipe</DialogTitle>
          <DialogContent>
            <TextField
              margin="dense"
              label="Recipe Title"
              fullWidth
              variant="outlined"
              value={newRecipe.title}
              onChange={(e) => setNewRecipe({...newRecipe, title: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Description"
              fullWidth
              multiline
              rows={2}
              variant="outlined"
              value={newRecipe.description}
              onChange={(e) => setNewRecipe({...newRecipe, description: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Ingredients (separate with commas)"
              fullWidth
              multiline
              rows={3}
              variant="outlined"
              value={newRecipe.ingredients}
              onChange={(e) => setNewRecipe({...newRecipe, ingredients: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Instructions"
              fullWidth
              multiline
              rows={4}
              variant="outlined"
              value={newRecipe.instructions}
              onChange={(e) => setNewRecipe({...newRecipe, instructions: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Tags (separate with commas)"
              fullWidth
              variant="outlined"
              value={newRecipe.tags}
              onChange={(e) => setNewRecipe({...newRecipe, tags: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Type (beverage, snack, main, dessert)"
              fullWidth
              variant="outlined"
              value={newRecipe.type}
              onChange={(e) => setNewRecipe({...newRecipe, type: e.target.value})}
            />
            <TextField
              margin="dense"
              label="Image URL (optional)"
              fullWidth
              variant="outlined"
              value={newRecipe.image}
              onChange={(e) => setNewRecipe({...newRecipe, image: e.target.value})}
            />
          </DialogContent>
          <DialogActions>
            <Button onClick={() => setRecipeOpen(false)}>Cancel</Button>
            <Button onClick={handleAddRecipe}>Add Recipe</Button>
          </DialogActions>
        </Dialog>
      </div>
    </ThemeProvider>
  );
};

export default MonsoonRecipeHub;